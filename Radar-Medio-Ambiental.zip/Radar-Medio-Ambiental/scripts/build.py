#!/usr/bin/env python3
"""Arma el Radar Medio Ambiental desde src/ y data/.

Uso:  python3 scripts/build.py [YYYY-MM-DDTHH:MM]
Genera:
  index.html          página completa para GitHub Pages
  dist/artifact.html  cuerpo para publicar como Artifact en Claude (sin doctype)
"""
import json, os, sys, datetime
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
p = lambda *a: os.path.join(ROOT, *a)

try:
    from zoneinfo import ZoneInfo
    now = datetime.datetime.now(ZoneInfo("America/Santiago")).strftime("%Y-%m-%dT%H:%M")
except Exception:
    now = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M")
publicado = sys.argv[1] if len(sys.argv) > 1 else now

hallazgos = json.load(open(p("data", "hallazgos.json"), encoding="utf-8"))
fuentes = json.load(open(p("data", "fuentes.json"), encoding="utf-8"))
ids = [h["id"] for h in hallazgos]
assert len(ids) == len(set(ids)), "ids duplicados en data/hallazgos.json"

data = {"publicado": publicado, "version": 1,
        "nota": "Se actualiza con una barrida automática de las fuentes listadas al pie.",
        "fuentes": fuentes, "hallazgos": hallazgos, "estadoFuentes": []}
js = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
body = (open(p("src", "template.html"), encoding="utf-8").read()
        .replace("{{LOGOS}}", open(p("src", "logos.html"), encoding="utf-8").read().rstrip("\n"))
        .replace("{{DATA}}", js))

os.makedirs(p("dist"), exist_ok=True)
open(p("dist", "artifact.html"), "w", encoding="utf-8").write(body)
page = ('<!doctype html><html lang="es"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
        '<style>:root{box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}'
        'body{margin:0}img{max-width:100%}[hidden]{display:none!important}</style></head><body>\n'
        + body + '\n</body></html>\n')
open(p("index.html"), "w", encoding="utf-8").write(page)
print(f"index.html ({len(page)//1024} KB) · {len(hallazgos)} hallazgos · {len(fuentes)} fuentes · publicado {publicado}")
