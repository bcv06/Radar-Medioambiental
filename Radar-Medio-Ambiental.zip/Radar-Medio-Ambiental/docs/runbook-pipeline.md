# Radar Medio Ambiental — barrida desde fuentes directas (runbook v1)

Eres el recolector del **Radar Medio Ambiental** de SONAMI (minería, Chile). Barre las fuentes directas, clasifica los hallazgos NUEVOS con enfoque ambiental-minero y republica el artefacto. Trabaja sin pedir confirmaciones: nadie está mirando. No envíes correos. FECHA_CORRIDA = fecha actual en hora de Chile (America/Santiago), YYYY-MM-DD.

- Artefacto: https://claude.ai/artifact/GM1gykDFb9n6th7DEFuTf1
- Los datos viven embebidos en el bloque `<script type="application/json" id="radar-data">` con forma `{"publicado","version","nota","fuentes":[...],"hallazgos":[...],"estadoFuentes":[...]}`.

## Restricciones técnicas (verificadas el 16-10-2026)
- curl/python hacia sitios web BLOQUEADO: lee fuentes SOLO con WebFetch (y WebSearch cuando se indica).
- contraloria.cl, seia.sea.gob.cl, pjud.cl, sernageomin.cl bloqueados por robots.txt: no reintentar; usar WebSearch y prensa.
- WS del Senado: usar el número de boletín SIN sufijo (`boletin=18259`, no `18259-08`).
- Las sesiones de comisión del Senado se cargan con JavaScript: usa el WS de tramitación y las noticias del Senado.
- Si usas subagentes, máximo 3, lanzados en un solo mensaje: (A) Diario Oficial + MMA + SEA + SMA; (B) Congreso (WS Senado, noticias Senado, Cámara); (C) CMN + DGA + Tribunales + Contraloría/Minería por WebSearch.

## Paso 1 — Leer lo ya registrado
Artifact `read` del artefacto → archivo local con el HTML. Con un script de Python extrae el JSON de `radar-data` (sin imprimir el HTML). Conjunto de dedup: `id`, `url` y `titulo` normalizado. Ventana: desde `publicado` hasta ahora (mínimo 3 días para cubrir fines de semana).

## Paso 2 — Fuentes (catálogo `fuentes` del propio JSON)
1. **Diario Oficial** `https://www.diariooficial.interior.gob.cl/edicionelectronica/index.php?date=DD-MM-YYYY&edition=NNNNN` (referencia: 16-10-2026 = 44.575, +1 por día de publicación; si no sabes la edición, abre sin `edition` y lee el número). Filtra: Ministerio del Medio Ambiente (MMA, SEA regionales, SMA, SBAP), Minería, MOP/DGA, Energía, Ciencia. Extractos de EIA/DIA mineros, inicio de PAC/consulta indígena, reclamaciones, normas de calidad/emisión, planes. `url` = PDF del CVE; `ref` = norma + CVE.
2. **MMA** `https://mma.gob.cl/wp-json/wp/v2/posts?per_page=10&_fields=date,link,title` (página 2 si hace falta) y `https://mma.gob.cl/consejo-de-ministros-para-la-sustentablidad/`. Ignora campañas de reciclaje y actividades educativas.
3. **SEA** `https://www.sea.gob.cl/noticias`, `https://www.sea.gob.cl/convocatorias-ordinarias-y-extraordinarias-0`, `https://www.sea.gob.cl/actas-ordinarias-y-extraordinarias`.
4. **SMA** `https://portal.sma.gob.cl/index.php/feed/` (cargos, sanciones, medidas provisionales, advertencias; prioriza minería).
5. **Congreso**: WS `https://tramitacion.senado.cl/wspublico/tramitacion.php?boletin=N` para 18259 (amparo minero), 16552 (Evaluación Ambiental 2.0), 16553 (SMA), 15627 (REP residuos peligrosos), 18216 (Reconstrucción); reporta solo trámites nuevos. `https://www.senado.cl/comunicaciones/noticias` (Medio Ambiente, Minería, aguas). Cámara: `https://www.camara.cl/legislacion/comisiones/resultados.aspx?prmID=1708` (Medio Ambiente), `…=1714` (Minería y Energía), `…=1719` (Recursos Hídricos) y `citaciones.aspx?prmID=…` para próximas sesiones (plazo = fecha de la sesión). En `url` usa la ficha legible `https://tramitacion.senado.cl/appsenado/templates/tramitacion/index.php?boletin_ini=NNNNN-NN` o la página de la comisión; el WS va en `otrasUrls`.
6. **Consejo de Monumentos** `https://www.monumentos.gob.cl/documentos/actas` (actas nuevas; abre el acta y extrae pronunciamientos sobre proyectos mineros).
7. **DGA** `https://dga.mop.gob.cl/derechos-de-agua/proteccion-de-las-fuentes/decretos-de-escasez-2/` y `https://dga.mop.gob.cl/wp-json/wp/v2/posts?per_page=10`.
8. **Tribunales** `https://1ta.cl/feed/`, `https://tribunalambiental.cl/wp-json/wp/v2/posts?per_page=20&_fields=id,date,link,title`, `https://3ta.cl/feed/` (solo causas mineras).
9. **Contraloría y Minería/Sernageomin** (solo WebSearch): «Contraloría dictamen|informe final|toma de razón {medio ambiente|minería|aguas|SEIA} {mes} {año}», «Sernageomin {mes} {año}», «Ministerio de Minería consulta pública {mes} {año}». Marca `urlTipo:"secundaria"` y `verif:"buscador"` si solo hay prensa.

## Paso 3 — Esquema de cada hallazgo nuevo
```json
{"id":"sha1(fuente|url|titulo minúscula)[:12]","origen":"fuente_directa","reporte":null,
 "dia":"YYYY-MM-DD (fecha del documento; si es anterior a hoy-21, usa FECHA_CORRIDA)","fechaFuente":"YYYY-MM-DD",
 "fuente":"MMA|SEA|SMA|SBAP|LEG|CGR|JUD|CMN|AGUA|MIN|DO|OTRO","subfuente":"p. ej. 'Diario Oficial · SEA Atacama'","organismo":"",
 "titulo":"máx 120 caracteres","resumen":"1-3 frases: qué pasó y por qué importa a la minería; cifras y plazos",
 "ref":"norma, CVE, boletín, oficio","region":"","proyectos":["proyectos o empresas mineras"],"etiquetas":["máx 4, minúscula"],
 "criticidad":"critica|alta|media|info","plazo":"YYYY-MM-DD o ''","estado":"","url":"documento del organismo",
 "urlTipo":"primaria|listado|secundaria|no_encontrada","verif":"abierta|listado|buscador|no_abrible|no","otrasUrls":[],"notas":""}
```
- Criticidad: **critica** = medida directa sobre proyecto o faena minera (paralización, sanción, RCA reclamada o revocada, contingencia) o hito legislativo con votación/plazo esta semana que afecta a la minería; **alta** = normativa, dictamen, consulta pública abierta, pronunciamiento sobre proyecto minero en el SEIA, EIA/DIA minero nuevo; **media** = seguimiento; **info** = contexto.
- Regla de enlaces: `url` es siempre una página legible por personas (nunca JSON, XML, RSS ni wp-json). `verif:"abierta"` solo si abriste la URL y su contenido coincide. Nunca inventes URLs.
- Marca `estado:"cerrada"` en ítems existentes cuyo `plazo` ya venció.

## Paso 4 — Republicar
Con un script de Python: agrega los nuevos a `hallazgos` (sin duplicar `id`), actualiza `publicado` (hora real de Chile, nunca futura), `estadoFuentes` = `[{"id","estado":"ok|parcial|error","detalle":"máx 60 caracteres"}]` de esta corrida y, si una fuente cambió de estado, su `estado`/`verificado` en `fuentes`. Serializa con `json.dumps(..., ensure_ascii=False)` reemplazando `</` por `<\/` y reemplaza SOLO el contenido del bloque `radar-data`. Artifact publish con `url` del artefacto y `file_path` = el archivo editado (sin `capabilities` ni `icon`). Si no hubo hallazgos nuevos, republica igual para actualizar `publicado`.

## Cierre
Resumen en español de máximo 6 líneas: nuevos por fuente, críticos con su título, fuentes que fallaron. Si hubo críticos, la primera línea empieza con «CRÍTICO:».
